import streamlit as st
import pandas as pd
import numpy as np
from joblib import load
from sklearn.impute import SimpleImputer

# -------------------------
# Load model, feature columns, and imputer
# -------------------------
@st.cache_resource
def load_model_and_preprocessing():
    model = load("insurance_model_sm.joblib")
    df = pd.read_csv("insurance.csv")
    if "id" in df.columns:
        df.drop(columns=["id"], inplace=True)

    # Feature columns used in training
    feature_cols = list(df.drop(["Response"], axis=1).columns)

    # Imputer for missing values
    imputer = SimpleImputer(strategy="mean")
    imputer.fit(df[feature_cols])

    return model, feature_cols, imputer

model, feature_cols, imputer = load_model_and_preprocessing()

# -------------------------
# Fixed mappings for categorical columns
# -------------------------
gender_map = {"Male": 1, "Female": 0}
vehicle_age_map = {"< 1 Year": 0, "1-2 Year": 1, "> 2 Years": 2}
vehicle_damage_map = {"Yes": 1, "No": 0}

# -------------------------
# Preprocess input dynamically
# -------------------------
def preprocess_input(data_dict):
    df_input = pd.DataFrame(data_dict)

    # Apply fixed mappings
    df_input["Gender"] = df_input["Gender"].map(gender_map)
    df_input["Vehicle_Age"] = df_input["Vehicle_Age"].map(vehicle_age_map)
    df_input["Vehicle_Damage"] = df_input["Vehicle_Damage"].map(vehicle_damage_map)

    # Auto-align features
    for col in feature_cols:
        if col not in df_input.columns:
            df_input[col] = np.nan

    df_input = df_input[feature_cols]  # reorder exactly

    # Impute missing values
    X_imp = imputer.transform(df_input)
    return X_imp

# -------------------------
# Streamlit UI
# -------------------------
st.set_page_config(page_title="Insurance Response Prediction", layout="wide")
st.title("🧠 Insurance Customer Response Prediction App")
st.write("Fill in customer details to predict insurance response.")

st.markdown("---")
st.subheader("🔹 Enter Customer Details")

col1, col2, col3 = st.columns(3)

with col1:
    gender = st.selectbox("Gender", ["Male", "Female"])
    age = st.number_input("Age", min_value=18, max_value=100, value=30)
    driving_license = st.selectbox("Driving License", [0, 1])

with col2:
    region_code = st.number_input("Region Code", min_value=0.0, max_value=100.0, value=28.0)
    previously_insured = st.selectbox("Previously Insured", [0, 1])
    vehicle_age = st.selectbox("Vehicle Age", ["< 1 Year", "1-2 Year", "> 2 Years"])

with col3:
    vehicle_damage = st.selectbox("Vehicle Damage", ["Yes", "No"])
    annual_premium = st.number_input("Annual Premium", min_value=0.0, value=30000.0)
    policy_sales_channel = st.number_input("Policy Sales Channel", min_value=0.0, max_value=200.0, value=26.0)
    vintage = st.number_input("Vintage (Days)", min_value=0, max_value=400, value=150)
    if "Premium_per_Vintage" in feature_cols:
        premium_per_vintage = st.number_input("Premium per Vintage", min_value=0.0, value=200.0)

# -------------------------
# Predict Button
# -------------------------
if st.button("Predict Response"):
    input_data = {
        "Gender": [gender],
        "Age": [age],
        "Driving_License": [driving_license],
        "Region_Code": [region_code],
        "Previously_Insured": [previously_insured],
        "Vehicle_Age": [vehicle_age],
        "Vehicle_Damage": [vehicle_damage],
        "Annual_Premium": [annual_premium],
        "Policy_Sales_Channel": [policy_sales_channel],
        "Vintage": [vintage],
    }
    if "Premium_per_Vintage" in feature_cols:
        input_data["Premium_per_Vintage"] = [premium_per_vintage]

    X_new = preprocess_input(input_data)
    y_pred = model.predict(X_new)[0]
    y_prob = model.predict_proba(X_new)[0][1]

    st.markdown("---")
    st.write(f"### 🎯 Predicted Response: **{int(y_pred)}**")
    if y_pred == 1:
        st.success("Customer is likely to respond (1).")
    else:
        st.warning("Customer is not likely to respond (0).")
    st.write(f"### 📊 Probability of Response: `{y_prob:.2%}`")
